
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Acer GK
 */
public class koneksi {

    private static Connection connection = null;
    private static final String DB_HOST = "localhost";
    private static final String DB_NAME = "koni_app";
    private static final String DB_USERNAME = "root";
    private static final String DB_PASSWORD = "";
    static Object preparedStatement;

    static void deleteAtlet(String ID_Atlet1, String NIK, String Nama, String TTL, String CABOR) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public koneksi() {
        try {
            Class.forName("com.mysql.jdbc.Driver");
            System.out.println("Driver loaded!");
        } catch (ClassNotFoundException e) {
            System.out.println("Failed to load driver!");
        }
    }


    public static Connection connect() {
        try {
            String url = "jdbc:mysql://" + DB_HOST + "/" + DB_NAME;
            connection = DriverManager.getConnection(url, DB_USERNAME, DB_PASSWORD);
            System.out.println("Database connected!");
            return connection;
        } catch (SQLException e) {
            System.out.println("Failed to connect database!"+e);
            return null;
        }
    }

    public static void disconnect() {
        try {
            if (connection != null && !connection.isClosed()) {
                connection.close();
                System.out.println("Database disconnected!");
            }
        } catch (SQLException e) {
            System.out.println("Failed to disconnect database!");
        }
    }
    
     public static Connection getKoneksi() {
        return connection;
     }
}
