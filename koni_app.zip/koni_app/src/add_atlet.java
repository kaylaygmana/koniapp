/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */

import java.sql.*;
import javax.swing.JOptionPane;
import java.sql.Connection;
import javax.swing.table.DefaultTableModel;
import java.sql.Statement;
import java.sql.ResultSet;
import javax.swing.table.TableModel;


/**
 *
 * @author Acer GK
 */
public class add_atlet extends javax.swing.JFrame {
     
    public add_atlet() {
        initComponents();
        koneksi.connect();
        table(); 
    }


    public void table() {
        DefaultTableModel table = new DefaultTableModel();
        table.addColumn("NIK ");
        table.addColumn("Nama");
        table.addColumn("TTL");
        table.addColumn("Kontingen");
        table.addColumn("Cabor");

        try {
            Statement statement = koneksi.getKoneksi().createStatement();
            ResultSet resultSet = statement.executeQuery("SELECT * FROM atlet");

            while (resultSet.next()) {
                table.addRow(new Object[]{
                        resultSet.getString("NIK"),
                        resultSet.getString("Nama"),
                        resultSet.getString("TTL"),
                        resultSet.getString("Kontingen"),
                        resultSet.getString("Cabor")
                });
            }

            tabel_atlet.setModel(table);

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Koneksi gagal! " + e.getMessage());
            e.printStackTrace();
        }
    }

    public void selectTugas(){
        int i = tabel_atlet.getSelectedRow();
        TableModel model = tabel_atlet.getModel();
        nik.setText(model.getValueAt(i, 1).toString());
        nama_atlet.setText(model.getValueAt(i, 2).toString());
        ttl.setText(model.getValueAt(i, 3).toString());
        kontingen.setText(model.getValueAt(i, 4).toString());
        cabor.setText(model.getValueAt(i, 5).toString());
    }


    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jFormattedTextField1 = new javax.swing.JFormattedTextField();
        jLabel2 = new javax.swing.JLabel();
        nik = new javax.swing.JTextField();
        jLabel14 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        nama_atlet = new javax.swing.JTextField();
        ttl = new javax.swing.JTextField();
        jLabel15 = new javax.swing.JLabel();
        cabor = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        tabel_atlet = new javax.swing.JTable();
        jLabel1 = new javax.swing.JLabel();
        submit = new javax.swing.JButton();
        kontingen = new javax.swing.JTextField();
        clear = new javax.swing.JButton();
        jLabel4 = new javax.swing.JLabel();
        bg = new javax.swing.JLabel();

        jLabel5.setFont(new java.awt.Font("Segoe UI Historic", 1, 14)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setText("Username");

        jLabel6.setFont(new java.awt.Font("Segoe UI Historic", 1, 14)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(255, 255, 255));
        jLabel6.setText("Username");

        jLabel7.setFont(new java.awt.Font("Segoe UI Historic", 1, 14)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(255, 255, 255));
        jLabel7.setText("Username");

        jLabel8.setFont(new java.awt.Font("Calibri Light", 0, 24)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(255, 255, 255));
        jLabel8.setText("LOGIN");

        jLabel9.setFont(new java.awt.Font("Segoe UI Historic", 1, 14)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(255, 255, 255));
        jLabel9.setText("Username");

        jFormattedTextField1.setText("jFormattedTextField1");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/btn_X.png"))); // NOI18N
        jLabel2.setText("jLabel2");
        jLabel2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel2MouseClicked(evt);
            }
        });
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(560, 0, 40, -1));

        nik.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        nik.setText("NIK");
        nik.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                nikMouseClicked(evt);
            }
        });
        getContentPane().add(nik, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 140, 260, -1));

        jLabel14.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/gymnast_1377353 (1).png"))); // NOI18N
        getContentPane().add(jLabel14, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 170, 110, -1));

        jLabel3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/SILAKAN PILIH LAYANAN (3).png"))); // NOI18N
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 100, -1, 60));

        jLabel16.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/healthy_1823726 (4).png"))); // NOI18N
        jLabel16.setText("jLabel16");
        getContentPane().add(jLabel16, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, 260, 160, -1));

        nama_atlet.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        nama_atlet.setText("Nama");
        nama_atlet.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                nama_atletMouseClicked(evt);
            }
        });
        getContentPane().add(nama_atlet, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 170, 260, -1));

        ttl.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        ttl.setText("Tempat Tanggal lahir");
        ttl.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                ttlMouseClicked(evt);
            }
        });
        getContentPane().add(ttl, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 200, 260, -1));

        jLabel15.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/Trash.png"))); // NOI18N
        jLabel15.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel15MouseClicked(evt);
            }
        });
        getContentPane().add(jLabel15, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 210, -1, -1));

        cabor.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        cabor.setText("Cabang Olahraga");
        cabor.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                caborFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                caborFocusLost(evt);
            }
        });
        cabor.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                caborMouseClicked(evt);
            }
        });
        getContentPane().add(cabor, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 260, 260, -1));

        tabel_atlet.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null}
            },
            new String [] {
                "ID Atlet", "NIK", "Nama", "TTL", "Kontingen", "Cabor"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, true
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tabel_atlet.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tabel_atletMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tabel_atlet);
        if (tabel_atlet.getColumnModel().getColumnCount() > 0) {
            tabel_atlet.getColumnModel().getColumn(0).setResizable(false);
            tabel_atlet.getColumnModel().getColumn(1).setResizable(false);
            tabel_atlet.getColumnModel().getColumn(2).setResizable(false);
            tabel_atlet.getColumnModel().getColumn(3).setResizable(false);
            tabel_atlet.getColumnModel().getColumn(4).setResizable(false);
        }

        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 340, -1, 140));

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/Edit (1).png"))); // NOI18N
        jLabel1.setText("jLabel1");
        jLabel1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel1MouseClicked(evt);
            }
        });
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 160, 40, -1));

        submit.setText("SUBMIT");
        submit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                submitActionPerformed(evt);
            }
        });
        getContentPane().add(submit, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 300, 80, -1));

        kontingen.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        kontingen.setText("Kontingen");
        kontingen.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                kontingenMouseClicked(evt);
            }
        });
        getContentPane().add(kontingen, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 230, 260, -1));

        clear.setText("CLEAR");
        clear.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                clearMouseClicked(evt);
            }
        });
        clear.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                clearActionPerformed(evt);
            }
        });
        getContentPane().add(clear, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 300, 80, -1));

        jLabel4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/back.png"))); // NOI18N
        jLabel4.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel4MouseClicked(evt);
            }
        });
        getContentPane().add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, -1, -1));

        bg.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/bg_logeen.png"))); // NOI18N
        bg.setText("NIK");
        getContentPane().add(bg, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 600, -1));

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void jLabel2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel2MouseClicked
        dispose();
    }//GEN-LAST:event_jLabel2MouseClicked

    private void clearActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_clearActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_clearActionPerformed

    private void clearMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_clearMouseClicked
    nik.setText("");
    nama_atlet.setText("");
    ttl.setText("");
    kontingen.setText("");
    cabor.setText("");
    }//GEN-LAST:event_clearMouseClicked

    private void nikMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_nikMouseClicked
     nik.setText("");
    }//GEN-LAST:event_nikMouseClicked

    private void nama_atletMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_nama_atletMouseClicked
        nama_atlet.setText("");
    }//GEN-LAST:event_nama_atletMouseClicked

    private void ttlMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ttlMouseClicked
        ttl.setText("");
    }//GEN-LAST:event_ttlMouseClicked

    private void caborFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_caborFocusGained
       
    }//GEN-LAST:event_caborFocusGained

    private void caborFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_caborFocusLost
        // TODO add your handling code here:
    }//GEN-LAST:event_caborFocusLost

    private void caborMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_caborMouseClicked
      cabor.setText("");
    }//GEN-LAST:event_caborMouseClicked

    private void submitActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_submitActionPerformed
    try {
    String sql = "INSERT INTO atlet (nik, nama, ttl, kontingen, cabor) VALUES ('"+nik.getText()+"','"+nama_atlet.getText()+"','"+ttl.getText()+"','"+kontingen.getText().toString()+"','"+cabor.getText()+"')";
    java.sql.Connection conn;
    conn = (Connection)koneksi.connect();
    java.sql.PreparedStatement pst = conn.prepareStatement(sql);
    pst.execute();
    JOptionPane.showMessageDialog(null, "Penyimpanan Data Berhasil");
    add_atlet add_atlet1 = new add_atlet();
    add_atlet1.setVisible(true);
    add_atlet1.pack();
    add_atlet1.setLocationRelativeTo(null);
    add_atlet1.setDefaultCloseOperation(add_atlet.EXIT_ON_CLOSE);
} catch (SQLException e) {
    JOptionPane.showMessageDialog(null, e.getMessage());
}

    }//GEN-LAST:event_submitActionPerformed

    private void tabel_atletMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tabel_atletMouseClicked
        int i = tabel_atlet.getSelectedRow();
        TableModel model = tabel_atlet.getModel();
        nik.setText(model.getValueAt(i, 0).toString());
        nama_atlet.setText(model.getValueAt(i, 1).toString());
        ttl.setText(model.getValueAt(i, 2).toString());
        kontingen.setText(model.getValueAt(i, 3).toString());
        cabor.setText(model.getValueAt(i, 4).toString());
    }//GEN-LAST:event_tabel_atletMouseClicked

    private void jLabel15MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel15MouseClicked
try {
    String nikToDelete = nik.getText();
    String sql = "DELETE FROM atlet WHERE nik = ?";
    
    java.sql.Connection conn;
    conn = (Connection) koneksi.connect();
    java.sql.PreparedStatement pst = conn.prepareStatement(sql);
    pst.setString(1, nikToDelete);
    
    int rowsAffected = pst.executeUpdate();
    
    if (rowsAffected > 0) {
        JOptionPane.showMessageDialog(null, "Penghapusan Data Berhasil");
        
        // Perbarui tabel setelah penghapusan
        DefaultTableModel model = (DefaultTableModel) tabel_atlet.getModel();
        model.setRowCount(0); // Menghapus semua baris dari tabel
        
        // Panggil metode untuk mengambil data dari database dan mengisi tabel
        table();
    } else {
        JOptionPane.showMessageDialog(null, "ID Atlet tidak ditemukan");
    }
} catch (SQLException e) {
    JOptionPane.showMessageDialog(null, e.getMessage());
}
    }//GEN-LAST:event_jLabel15MouseClicked

    private void jLabel1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel1MouseClicked
  try {
    String newNik = nik.getText();
    String newNamaAtlet = nama_atlet.getText();
    String newTtl = ttl.getText();
    String newKontingen = kontingen.getText();
    String newCabor = cabor.getText();

    String sql = "UPDATE atlet SET nik=?, nama=?, ttl=?, kontingen=?, cabor=? WHERE nik=?";
    
    java.sql.Connection conn;
    conn = (Connection) koneksi.connect();
    java.sql.PreparedStatement pst = conn.prepareStatement(sql);
    
    pst.setString(1, newNik);
    pst.setString(2, newNamaAtlet);
    pst.setString(3, newTtl);
    pst.setString(4, newKontingen);
    pst.setString(5, newCabor);
    pst.setString(6, newNik);

    int rowsAffected = pst.executeUpdate();
    
    if (rowsAffected > 0) {
        JOptionPane.showMessageDialog(null, "Pembaruan Data Berhasil");

        DefaultTableModel model = (DefaultTableModel) tabel_atlet.getModel();
        model.setRowCount(0); // Menghapus semua baris dari tabel
        
        table();
    } else {
        JOptionPane.showMessageDialog(null, "ID Atlet tidak ditemukan");
    }
} catch (SQLException e) {
    JOptionPane.showMessageDialog(null, e.getMessage());
}

    }//GEN-LAST:event_jLabel1MouseClicked

    private void jLabel4MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel4MouseClicked
        Menu_Utama MENU_UTAMA = new Menu_Utama();
        MENU_UTAMA.setLocationRelativeTo(null);
        MENU_UTAMA.setVisible(true);
        MENU_UTAMA.pack();
        MENU_UTAMA.setLocationRelativeTo(null);
        MENU_UTAMA.setDefaultCloseOperation(add_atlet.EXIT_ON_CLOSE);
        dispose();
        
    }//GEN-LAST:event_jLabel4MouseClicked

    private void kontingenMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_kontingenMouseClicked
           kontingen.setText("");
    }//GEN-LAST:event_kontingenMouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(add_atlet.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(add_atlet.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(add_atlet.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(add_atlet.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new add_atlet().setVisible(true);
            }
        });
    }


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel bg;
    private javax.swing.JTextField cabor;
    private javax.swing.JButton clear;
    private javax.swing.JFormattedTextField jFormattedTextField1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextField kontingen;
    private javax.swing.JTextField nama_atlet;
    private javax.swing.JTextField nik;
    private javax.swing.JButton submit;
    private javax.swing.JTable tabel_atlet;
    private javax.swing.JTextField ttl;
    // End of variables declaration//GEN-END:variables

//    private void initOmponents() {
//        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
//}
